Given /^i m on a shopping website$/ do 
	visit "http://www.flipkart.com"
end

When /^i search for "(.*?)"$/ do |book|
	fill_in "fk-top-search-box", :with => book
	find(:xpath, "//input[@class='fk-main-search-btn']").click
	assert page.has_content?("Books Home")
end

When /^select the book$/ do
	click_button("Buy Now")
	#find(:xpath, "//button[@class='place-order-button fk-button orange unitExt']").click
end

When /^place an order$/ do
	find(:xpath, "//button[@class='place-order-button fk-button orange unitExt']").click

end

Then /^i should see "(.*?)"$/ do |message|
	assert_equal "Flipkart.com: Secure Payment: Login > Select Shipping Address > Review Order > Place Order",page.find(:css,'title').text
	@msg = message
	fill_in "email-id", :with => "saileebhekare@gmail.com"
	#find(:xpath,"//input[@class='fk-button orange fk-font-big']").click

	@xpath="//form[@id='co-login-form']/div/div/div[@class='lastUnit lpadding10 tpadding5']/div[@class='tmargin10']/input"
	find(:xpath, @xpath)
	
	fill_in "co_createaddr_name", :with => "sailee"
	fill_in "co_createaddr_addr1", :with => "kalwa"
	fill_in "co_createaddr_city" , :with => "Thane"
	fill_in "co_createaddr_pincode", :with => "400605"
	fill_in "co_createaddr_phone", :with => "02225377774"
	
	#@xpath="id('co_createaddr_state')/option[@value='Maharashtra']"
	#@option= find(:xpath,@xpath).text 	
	#select(@option, :from => "co_createaddr_state")
	select('Maharashtra',:from => "co_createaddr_state")
	find(:xpath, "(//input[@class='co_btn'])[1]").click 

	#assert page.has_content?(@msg)
end

