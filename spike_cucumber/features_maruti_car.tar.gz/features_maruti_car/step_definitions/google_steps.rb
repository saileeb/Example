Given /^that i am on "(.*?)"$/ do |url|
	visit url
end

When /^enter "(.*?)" with "(.*?)"$/ do |name_id, name|
	fill_in name_id, :with => name
end

When /^enter the "(.*?)" with "(.*?)"$/ do |mobile_id, mobile|
	fill_in mobile_id, :with => mobile
end

When /^type the "(.*?)" with email "(.*?)"$/ do |email_id,email|
	fill_in email_id, :with => email
end

When /^i select "(.*?)" with option "(.*?)"$/ do |select_id, option|
	@xpath="id('"+select_id+"')/option[@value='"+option+"']"
	@option= find(:xpath,@xpath).text 	
	select(@option, :from => select_id) 
end

When /^click on "(.*?)"$/ do |submit_button|
	click_button(submit_button)
end

Then /^the page should contain "(.*?)"$/ do |message|
	assert page.has_content?(message)
end

